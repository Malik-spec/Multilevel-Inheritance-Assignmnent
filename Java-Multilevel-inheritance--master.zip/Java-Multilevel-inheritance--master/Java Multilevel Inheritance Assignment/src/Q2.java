
class Account{
	String customer_name = "Nicola Tesla";
	double account_no = 204980;
	void display() {
		System.out.println(" Customer Name: " +customer_name);
		System.out.println(" Account Number: " +account_no);
	}
}

class Saving_Account extends Account{
	int min_bal = 2000;
	int saving_bal = 3000;
	void display() {
		super.display();
		System.out.println(" Minimum Balance: " +min_bal);
		System.out.println(" Savings Balance: " +saving_bal);
		
		
	}
	
	
}


class Account_Details extends Saving_Account{
	double deposits = 1500;
	double withdrawals = 1000;
	void display() {
		super.display();
		System.out.println(" Deposit: " +deposits);
		System.out.println(" Withdrawal: " +withdrawals);
		
	}
	
	
	
}


public class Q2 {

	public static void main(String[] args) {
		// Object of the Account_Details 
		Account_Details a = new Account_Details();
		a.display();
		

	}

}
