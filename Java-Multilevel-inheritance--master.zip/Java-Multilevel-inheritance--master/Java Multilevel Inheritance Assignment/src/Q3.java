class Person{
	void nationality() {
		System.out.println("Ghana");
		
	}
	void place() {
		System.out.println("Accra");
		
	}
}

class Emp extends Person{
	void organization() {
		System.out.println("Amalitech");
		
	}
	
	void place() {
		System.out.println("Takoradi");
	}
}

class Manager extends Emp{
	void subordinates() {
		System.out.println("Code Academy");
	}
	void place() {
		System.out.println("World");
	}
}



public class Q3 {

	public static void main(String[] args) {
		Manager m = new Manager();
		m.place();
		m.nationality();
		m.organization();
		
		

	}

}
